import React, { useState, useEffect } from "react";
import { FiArrowRight } from "react-icons/fi";
import InputField from "./InputField";
import { registerTeacher, getOrgList } from "../../api/auth";

const TeacherForm = ({ onRegisterSuccess, showToast }) => {
  const [formData, setFormData] = useState({
    name: "",
    orgCode: "",
    subject: "",
    email: "",
  });

  const [errors, setErrors] = useState({});
  const [organizations, setOrganizations] = useState([]);
  const [loading, setLoading] = useState(false);
  const [loadingOrgs, setLoadingOrgs] = useState(true);

  useEffect(() => {
    const fetchOrganizations = async () => {
      try {
        const response = await getOrgList();
        if (response.status === 200) {
          setOrganizations(response.data.organizations || []);
        }
      } catch {
        showToast("error", "Failed to load organizations");
      } finally {
        setLoadingOrgs(false);
      }
    };

    fetchOrganizations();
  }, []);

  const handleChange = (e) =>
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));

  const validate = () => {
    let newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Name is required";
    if (!formData.orgCode.trim()) newErrors.orgCode = "Select organization";
    if (!formData.subject.trim()) newErrors.subject = "Subject is required";
    if (!formData.email.trim()) newErrors.email = "Email is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const submit = async (e) => {
    e.preventDefault();
    if (!validate()) {
      showToast("error", "Please fill all required fields");
      return;
    }

    setLoading(true);
    try {
      const response = await registerTeacher(formData);
      console.log(response);

      if (response.status === 201) {
        showToast(
          "success",
          "Registration submitted! Wait for organization approval."
        );
        onRegisterSuccess("login");
      } else {
        showToast("error", response.data.message || "Registration failed");
      }
    } catch (error) {
      const message =
        error.response?.data?.message || "Server error. Please try again.";
      showToast("error", message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-4 mt-3 text-xs md:text-sm px-2">
      <InputField
        label="Name"
        name="name"
        placeholder="Full name"
        value={formData.name}
        onChange={handleChange}
        error={errors.name}
      />

      <div className="flex flex-col gap-1">
        <label className="text-[11px] text-gray-300 font-semibold">
          Organization
        </label>

        <select
          name="orgCode"
          value={formData.orgCode}
          onChange={handleChange}
          disabled={loadingOrgs}
          className={`w-full text-gray-100 px-3 py-2 rounded-md text-xs appearance-none
            border ${errors.orgCode ? "border-red-500" : "border-gray-700"}
            bg-gradient-to-r from-[#07182a] via-[#0b2230] to-[#0f2b39]
            hover:from-[#0b2230] hover:to-[#113544]
            focus:ring-2 focus:ring-emerald-500 transition-all duration-150
            disabled:opacity-50 disabled:cursor-not-allowed`}
        >
          <option className="bg-[#0d0d0e] text-gray-200" value="">
            {loadingOrgs ? "Loading..." : "-- Select Organization --"}
          </option>
          {organizations.map((org) => (
            <option
              key={org.orgCode}
              value={org.orgCode}
              className="bg-[#0d0d0e] text-gray-200"
            >
              {org.orgName}
            </option>
          ))}
        </select>

        {errors.orgCode && (
          <span className="text-[10px] text-red-400">{errors.orgCode}</span>
        )}
      </div>

      <InputField
        label="Subject"
        name="subject"
        placeholder="Ex: Mathematics, Physics"
        value={formData.subject}
        onChange={handleChange}
        error={errors.subject}
      />

      <InputField
        label="Email"
        type="email"
        name="email"
        placeholder="Official email"
        value={formData.email}
        onChange={handleChange}
        error={errors.email}
      />

      <button
        type="submit"
        disabled={loading || loadingOrgs}
        className="w-full p-3 bg-emerald-600 hover:bg-emerald-500 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg shadow-lg text-xs font-semibold flex items-center justify-center gap-2 mt-2 transition"
      >
        {loading ? "Submitting..." : "Submit"}
        {!loading && <FiArrowRight className="w-4 h-4" />}
      </button>
    </form>
  );
};

export default TeacherForm;
